#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "graph.hpp"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
     MainWindow(QWidget *parent = nullptr,graph *pGraph = nullptr);
    ~MainWindow();
     void SetGraph(graph *pGraph);

private slots:
    void on_btBuild_clicked();

    void on_btEdit_clicked();

    void on_btAnalize_clicked();

    void on_btSave_clicked();

    void on_btLoad_clicked();

    void on_btEnd_clicked();

private:
    Ui::MainWindow *ui;
    graph *grafo = nullptr;
};
#endif // MAINWINDOW_H
