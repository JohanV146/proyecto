#include "build.h"
#include "ui_build.h"
#include <QMessageBox>

Build::Build(QWidget *parent, MainWindow *fat) :
    QDialog(parent),
    ui(new Ui::Build)
{
    ui->setupUi(this);
    padre = fat;
    ui->label_3->hide();
    ui->label_4->hide();
    ui->label_5->hide();
    ui->label_6->hide();
    ui->label_7->hide();
    ui->label_8->hide();
    ui->label_9->hide();
    ui->btAgregar->hide();
    ui->btInsertar->hide();
    ui->txtCost->hide();
    ui->txtVer1->hide();
    ui->txtVer2->hide();
    ui->name->hide();
    ui->txtName->hide();

}

Build::~Build()
{
    delete ui;
}

void Build::on_btContinuar_clicked()
{

    padre->SetGraph(grafo);
    this->close();

}


void Build::on_btRegresar_clicked()
{
    if(grafo != nullptr){
       padre->SetGraph(grafo);
        this->close();
    }else {
        this->close();
    }

}


void Build::on_Crear_clicked()
{
    QString text = ui->txtText->text();
    if(text != ""){
        bool dirigido = ui->rdbtDirigido->isChecked();
        bool peso = ui->rdbtPeso->isChecked();
        graph *g = new graph(dirigido, peso, text.toStdString());
        grafo = g;
        QMessageBox::information(this,"Info","Grafo creado con exito!");
        ui->label_3->setVisible(true);
        ui->label_4->setVisible(true);
        ui->label_5->setVisible(true);
        ui->label_6->setVisible(true);
        ui->label_7->setVisible(true);
        ui->label_8->setVisible(true);
        ui->label_9->setVisible(true);
        ui->btAgregar->setVisible(true);
        ui->btInsertar->setVisible(true);
        ui->txtCost->setVisible(true);
        ui->txtVer1->setVisible(true);
        ui->txtVer2->setVisible(true);
        ui->name->setVisible(true);
        ui->txtName->setVisible(true);

    }else{
        QMessageBox::information(this,"Error", "Debes escribir el nombre");
    }
}


void Build::on_btAgregar_clicked()
{
    QString name = ui->txtName->text();
    if(name!=""){
        grafo->insertVertex(name.toStdString());
        ui->txtName->clear();
        QMessageBox::information(this,"Vertice Añadido", "Se ha agregado el vertice con exito");
    }else{
        QMessageBox::information(this,"Error", "No se puede agregar un vertice sin nombre");
    }
}


void Build::on_btInsertar_clicked()
{
    QString v1 = ui->txtVer1->text();
    QString v2 = ui->txtVer2->text();
    QString cost = ui->txtCost->text();
    if(v1!= "" && v2!="" && cost!=""){
        if(grafo->getWeighted()){
            int pesoC;
            bool ok;
            pesoC = cost.toInt(&ok);
            if(ok){
                grafo->insertConnection(v1.toStdString(),v2.toStdString(),pesoC);
                QMessageBox::information(this,"Conexion Añadida", "Se ha agregado la conexion con exito");
            }
        }else{
            grafo->insertConnection(v1.toStdString(),v2.toStdString());
            QMessageBox::information(this,"Conexion Añadida", "Se ha agregado la conexion con exito");
        }
    }else{
        QMessageBox::information(this,"Error", "Debe llenar todos los campos");
    }
}

