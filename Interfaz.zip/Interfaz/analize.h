#ifndef ANALIZE_H
#define ANALIZE_H

#include <QDialog>
#include "mainwindow.h"
#include "graph.hpp"
#include <QPainter>

namespace Ui {
class Analize;
}

class Analize : public QDialog
{
    Q_OBJECT

public:
    explicit Analize(QWidget *parent = nullptr, MainWindow *fat = nullptr, graph *grafos= nullptr);
    ~Analize();

private slots:
    void on_btMatriz_clicked();

    void on_btBusqueda_clicked();

    void on_btTodosCaminos_clicked();

    void on_btArbol_clicked();

    void on_btRegresar_clicked();

private:
    Ui::Analize *ui;
    MainWindow *padre;
    graph *grafo = nullptr;
};

#endif // ANALIZE_H
