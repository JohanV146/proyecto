#ifndef BUILD_H
#define BUILD_H

#include <QDialog>
#include "mainwindow.h"
#include "graph.hpp"

namespace Ui {
class Build;
}

class Build : public QDialog
{
    Q_OBJECT

public:
    explicit Build(QWidget *parent = nullptr, MainWindow *fat=nullptr);
    ~Build();

private slots:
    void on_btContinuar_clicked();

    void on_btRegresar_clicked();

    void on_Crear_clicked();

    void on_btAgregar_clicked();

    void on_btInsertar_clicked();

private:
    Ui::Build *ui;
    MainWindow *padre;
    graph *grafo = nullptr;
};

#endif // BUILD_H
