#include "edit.h"
#include "ui_edit.h"
#include <QMessageBox>

Edit::Edit(QWidget *parent, MainWindow *fat, graph *grafos) :
    QDialog(parent),
    ui(new Ui::Edit)
{
    ui->setupUi(this);
    padre = fat;
    grafo = grafos;
    if (grafo->getDirected()){
        ui->btDirigido->setCheckState(Qt::CheckState(true));
    }
    if(grafo->getWeighted()){
        ui->btPeso->setCheckState(Qt::CheckState(true));
    }
}

Edit::~Edit()
{
    delete ui;
}

void Edit::on_btCambiarDiir_clicked()
{
    QMessageBox::information(this,"Cambiado","Cambiado con exito!");
}


void Edit::on_btCambiarPess_clicked()
{
    QMessageBox::information(this,"Cambiado","Cambiado con exito!");
}


void Edit::on_btAgregar_clicked()
{
    QString name= ui->txtName->text();
    if(name!= ""){
        grafo->insertVertex(name.toStdString());
         QMessageBox::information(this,"Agregado","Agregado con exito!");
    }else{
         QMessageBox::information(this,"Error","Debe escribir algo");
    }
}


void Edit::on_btInsertar_clicked()
{
    QString v1 = ui->txtVwe1->text();
    QString v2 = ui->txtVer2->text();
    QString cost = ui->txtCost->text();
    if(v1!= "" && v2!="" && cost!=""){
        if(grafo->getWeighted()){
            int pesoC;
            bool ok;
            pesoC = cost.toInt(&ok);
            if(ok){
                grafo->insertConnection(v1.toStdString(),v2.toStdString(),pesoC);
                QMessageBox::information(this,"Conexion Añadida", "Se ha agregado la conexion con exito");
            }
        }else{
            grafo->insertConnection(v1.toStdString(),v2.toStdString());
            QMessageBox::information(this,"Conexion Añadida", "Se ha agregado la conexion con exito");
        }
    }else{
        QMessageBox::information(this,"Error", "Debe llenar todos los campos");
    }
}


void Edit::on_btFin_clicked()
{
    padre->SetGraph(grafo);
    this->close();
}

