#include "dialog.h"
#include "ui_dialog.h"
#include <QStandardItemModel>
#include "node.hpp"

Dialog::Dialog(QWidget *parent, Analize *fat, graph *grafos) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    grafo = grafos;
}

Dialog::~Dialog()
{
    delete ui;
}


void Dialog::on_btCargar_clicked()
{
    ui->table->setColumnCount(grafo->getVCount());
    ui->table->setRowCount(grafo->getVCount());

    QStringList l;
    for (node *t= grafo->getVertex();t !=nullptr; t = t->getNextV()){
        l<< QString::fromStdString(t->getName());
    }
    ui->table->setHorizontalHeaderLabels(l);
    for (int i = 0; i< grafo->getVCount(); i++){
        ui->table->setColumnWidth(i, 100);
    }
    QStringList h;
    for(node *t= grafo->getVertex();t !=nullptr; t = t->getNextV()){
        h<< QString::fromStdString(t->getName());
    }
    ui->table->setVerticalHeaderLabels(h);
    for (int i = 0; i< grafo->getVCount(); i++){
        ui->table->setRowHeight(i, 50);
    }
}

