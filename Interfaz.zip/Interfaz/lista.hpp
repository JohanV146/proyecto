#ifndef LISTA_HPP
#define LISTA_HPP

#include <iostream>
#include "nodeLista.hpp"

using namespace std;

class lista {
private:
	nodeLista *cabeza;
	nodeLista *next;

public:
	lista() {
		this->cabeza = nullptr;
		this->next = nullptr;
	}

	void insertar(int a, string b) {
		if (cabeza == nullptr) {
			nodeLista *temp = new nodeLista(b, a);
			cabeza = temp;

		}else {
			nodeLista *temp = cabeza;
			while(temp->getNext() != nullptr) {
				temp = temp->getNext();
			}
			nodeLista *aux = new nodeLista(b, a);
			temp->setNext(aux);
		}
	}

	void print() {
		nodeLista *temp = cabeza;
		char *name;
		while(temp != nullptr) {
			cout << "[" << strcpy(name, temp->getName ().c_str()) << "]" << " " << "Costo (" << temp->getPeso() << ")" << endl;
			temp = temp->getNext(); 
		}
	}

	void setCabeza() {this->cabeza = nullptr;}

};

#endif
