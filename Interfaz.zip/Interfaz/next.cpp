#include "next.h"
#include "build.h"
#include "graph.hpp"
#include "ui_next.h"
#include <QMessageBox>
#include "mainwindow.h"



Next::Next(QWidget *parent, MainWindow *fat, graph *grafos) :
    QDialog(parent),
    ui(new Ui::Next)
{
    ui->setupUi(this);
    padre = fat;
    grafo = grafos;
}

Next::~Next()
{
    delete ui;
}


void Next::on_btAgregar_clicked()
{
    QString name = ui->txtName->text();
    if(name!=""){
        grafo->insertVertex(name.toStdString());
        ui->txtName->clear();
        QMessageBox::information(this,"Vertice Añadido", "Se ha agregado el vertice con exito");
    }else{
        QMessageBox::information(this,"Error", "No se puede agregar un vertice sin nombre");
    }
}


void Next::on_btInsertar_clicked()
{
    QString v1 = ui->txtVer1->text();
    QString v2 = ui->txtVer2->text();
    QString cost = ui->txtCost->text();
    if(v1!= "" && v2!="" && cost!=""){
        if(grafo->getWeighted()){
            int pesoC;
            bool ok;
            pesoC = cost.toInt(&ok);
            if(ok){
                grafo->insertConnection(v1.toStdString(),v2.toStdString(),pesoC);
                QMessageBox::information(this,"Conexion Añadida", "Se ha agregado la conexion con exito");
            }
        }else{
            grafo->insertConnection(v1.toStdString(),v2.toStdString());
            QMessageBox::information(this,"Conexion Añadida", "Se ha agregado la conexion con exito");
        }
    }else{
        QMessageBox::information(this,"Error", "Debe llenar todos los campos");
    }

}


void Next::on_btFinalizar_clicked()
{
   padre->SetGraph(grafo);
   this->close();
}


void Next::on_btRegresar_clicked()
{
    this->close();
}

