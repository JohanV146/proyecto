#ifndef SAVE_H
#define SAVE_H

#include <QDialog>
#include "mainwindow.h"
#include "graph.hpp"

namespace Ui {
class Save;
}

class Save : public QDialog
{
    Q_OBJECT

public:
    explicit Save(QWidget *parent = nullptr, MainWindow *fat= nullptr, graph *grafos = nullptr);
    ~Save();

private:
    Ui::Save *ui;
    MainWindow *padre;
    graph *grafo = nullptr ;
};

#endif // SAVE_H
