#ifndef EDIT_H
#define EDIT_H

#include <QDialog>
#include "mainwindow.h"
#include "graph.hpp"

namespace Ui {
class Edit;
}

class Edit : public QDialog
{
    Q_OBJECT

public:
    explicit Edit(QWidget *parent = nullptr, MainWindow *fat = nullptr, graph *grafos = nullptr);
    ~Edit();

private slots:
    void on_btCambiarDiir_clicked();

    void on_btCambiarPess_clicked();

    void on_btAgregar_clicked();

    void on_btInsertar_clicked();

    void on_btFin_clicked();

private:
    Ui::Edit *ui;
    MainWindow *padre;
    graph *grafo = nullptr;
};

#endif // EDIT_H
