#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "analize.h"
#include "build.h"
#include "edit.h"
#include "load.h"
#include "save.h"
#include "graph.hpp"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Visualizador de Grafos");
}

MainWindow::MainWindow(QWidget *parent, graph *pGraph)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Visualizador de Grafos");
    grafo = pGraph;
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_btBuild_clicked()
{
    Build *b = new Build(this,this);
    b->setModal(true);
    b->show();
    b->setWindowTitle("Creacion de Grafo");
    this->close();
}

void MainWindow::SetGraph(graph* pGraph){
    grafo = pGraph;
}

void MainWindow::on_btEdit_clicked()
{
    if(grafo != nullptr){
        Edit *edtg = new Edit(this,this,grafo);
        edtg->setModal(true);
        edtg->show();
        edtg->setWindowTitle("Editar Grafos");
        this->close();
    }
    else{
        QMessageBox::information(this, "Error", "debe tener un grafo creado o cargado");
    }
}


void MainWindow::on_btAnalize_clicked()
{
    if(grafo != nullptr){
        Analize *anlg = new Analize(this,this,grafo);
        anlg->setModal(true);
        anlg->show();
        anlg->setWindowTitle("Editar Grafos");
        this->close();
    }
    else{
        QMessageBox::information(this, "Error", "debe tener un grafo creado o cargado");
    }

}


void MainWindow::on_btSave_clicked()
{
    if(grafo != nullptr){
        Save *sg = new Save(this,this,grafo);
        sg->show();
        sg->setWindowTitle("Editar Grafos");
        this->close();
    }
    else{
        QMessageBox::information(this, "Error", "debe tener un grafo creado o cargado");
    }
}


void MainWindow::on_btLoad_clicked()
{
    if(grafo != nullptr){
        Load *lg = new Load(this,this,grafo);
        lg->show();
        lg->setWindowTitle("Editar Grafos");
        this->close();
    }
    else{
        QMessageBox::information(this, "Error", "debe tener un grafo creado o cargado");
    }
}


void MainWindow::on_btEnd_clicked()
{

}

