#ifndef NODELISTA_HPP
#define NODELISTA_HPP

#include <string.h>

class nodeLista {
    private:
        nodeLista *next;
        int peso;
        string name;
    
    public:
        nodeLista(string a, int p) {
            this->peso = p;
            this->name = a;
            this->next = nullptr;
        }

        nodeLista* getNext() {return next;}
        void setNext(nodeLista *a) {this->next = a;}
        int getPeso() {return peso;}
        void setPeso(int a) {this->peso = a;}
        string getName() {return this->name;}
        void setName(string a) {this->name = a;}
};



#endif