#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include "analize.h"
#include "graph.hpp"
#include "mainwindow.h"

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr, Analize *fat = nullptr,graph *grafos = nullptr);
    ~Dialog();

private slots:
    void on_btCargar_clicked();

private:
    Ui::Dialog *ui;
    MainWindow *padre;
    graph *grafo = nullptr;
};

#endif // DIALOG_H
