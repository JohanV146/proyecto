#include "save.h"
#include "ui_save.h"

Save::Save(QWidget *parent, MainWindow *fat, graph *grafos) :
    QDialog(parent),
    ui(new Ui::Save)
{
    ui->setupUi(this);
    padre = fat;
    grafo = grafos;
}

Save::~Save()
{
    delete ui;
}
