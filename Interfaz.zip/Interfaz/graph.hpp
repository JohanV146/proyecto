#ifndef GRAPH_HPP
#define GRAPH_HPP
#include <iostream>
#include "node.hpp"
#include "lista.hpp"

using namespace std;

class graph {
	
private:
	node *vertex;
	bool  directed;
	bool  weighted;
	int	  vCount;
    string nameG;
	lista *camino;
public:
	static const int DIRECTED 	 = true;
	static const int NOTDIRECTED = false;
	static const int WEIGHTED 	 = true;
	static const int NOTWEIGHTED = false;

    graph (bool d, bool w, string nameG) {
		vertex = nullptr;
		directed = d;
		weighted = w;
		vCount = 0;
        this->nameG = nameG;
		this->camino = new lista();
	}
	
	int getVCount () {
		return vCount;
	}

	bool getWeighted () { return weighted; }
	bool getDirected () { return directed; }

	//Se encarga de insertar vertices.
	void insertVertex (string name) {
		node *newVertex = new node(name);
		newVertex->setNextV (vertex);
		vertex = newVertex;
		vCount++;
	}

	//Retorna el nombre del nodo, se encarga de encontrar el vertice.
	char* seekV (int i) {
		char* name;
		if (i >= vCount)
			return (char*)'\0';
		node *t = vertex;
		for (int p = 0; p < i; p++)
			t = t->getNextV ();
		return strcpy(name, t->getName ().c_str());
	}

	//Retorna el nodo, se encarga de buscar el vertice.
	node* seekV (string pVertexName) {
		string nameVertex = pVertexName;

		for (node *t = vertex; t != nullptr; t = t->getNextV ())
			if (nameVertex == t->getName ())
				return t;
		return nullptr;
	}

	//Se encarga de buscar la conexion.
	node* seekC (string vertex1, string vertex2) {
		node *node1 = seekV (vertex1);
		string toCompare = vertex2;
		if (node1 != nullptr)
			for (node *t = node1->getNextA (); t != nullptr; t = t->getNextA ())
				if (toCompare == t->getName ())
					return t;
		return nullptr;
	}
    //devuelve el vertice
    node* getVertex() {return vertex;}

	//Se encarga de insertar las conexiones.
	void insertConnection (string vertex1, string vertex2, int cost) {
		node *n1 = seekV (vertex1);
		node *n2 = seekV (vertex2);

		if (n1 == nullptr) {
			insertVertex (vertex1);
			n1 = seekV (vertex1);
		}
		if (n2 == nullptr) {
			insertVertex (vertex2);
			n2 = seekV (vertex2);
		}

		node *c1 = seekC (vertex1, vertex2);

		if (c1 == nullptr) {
			node *t = n1->getNextA ();
			node *n = new node (vertex2, cost);

			n1->setNextA (n);
			n->setNextA (t);
		} else c1->setCost (cost);

		if (!directed) {
			node *c2 = seekC (vertex2, vertex1);
			if (c2 == nullptr) {
				node *t = n2->getNextA ();
				node *n = new node (vertex1, cost);

				n2->setNextA (n);
				n->setNextA (t);
			} else c2->setCost (cost);
		}
	}

	//Inserta por default.
	void insertConnection (string v1, string v2) {
		insertConnection (v1, v2, 1);
	}


	lista* caminosCortos(string vertice) {
		node *inicio = seekV(vertice);
		camino->setCabeza();

		if (inicio != nullptr) {
			if (inicio->getNextA() != nullptr) {
				limpiarMarcas();
				camino->insertar(0, inicio->getName());
				recorrido(inicio->getName());
				caminosCortos(inicio);
			}
		} 

		return camino;
		
	}


	void caminosCortos(node *inicio) {
		node *menor = new node("", 999999999);
		
		for (node *n = inicio->getNextA(); n != nullptr; n = n->getNextA()) {
			if (!n->getMark()) {
				if (menor->getCost() > n->getCost()) {
					menor = n;
				}
			}
		}

		if (menor->getCost() != 999999999) {
			camino->insertar(menor->getCost(), menor->getName());
			menor = seekV(menor->getName());
			recorrido(menor->getName());
			caminosCortos(menor);
		}
	}

	void recorrido(string name) {
		for (node *v = vertex; v != nullptr; v = v->getNextV ()) {
			if (v->getName() == name) {
				v->setMark();
			}
            for (node *a = v->getNextA (); a != nullptr; a = a->getNextA ()) {
				if (a->getName() == name) {
					a->setMark();
				}
			} 
		}          
	}


	void limpiarMarcas() {
		for (node *v = vertex; v != nullptr; v = v->getNextV()) {
			v->clearMark();
		}
	}

    void print () {
		char *name;
		for (node *v = vertex; v != nullptr; v = v->getNextV ()) {
            std::cout << "[" << v << "]:[" << strcpy(name, v->getName ().c_str()) << "]";
            for (node *a = v->getNextA (); a != nullptr; a = a->getNextA ())
                std::cout << "->" << strcpy(name, a->getName ().c_str()) << "(" << a->getCost () << ")";
            std::cout << std::endl;
        }
	}
	
    string getName() {
        return this->nameG;
    }
};
#endif
