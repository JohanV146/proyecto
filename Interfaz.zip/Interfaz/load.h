#ifndef LOAD_H
#define LOAD_H

#include <QDialog>
#include "mainwindow.h"
#include "graph.hpp"

namespace Ui {
class Load;
}

class Load : public QDialog
{
    Q_OBJECT

public:
    explicit Load(QWidget *parent = nullptr, MainWindow *fat= nullptr, graph *grafos = nullptr);
    ~Load();

private:
    Ui::Load *ui;
    MainWindow *padre;
    graph *grafo = nullptr;
};

#endif // LOAD_H
