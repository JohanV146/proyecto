#include "load.h"
#include "ui_load.h"

Load::Load(QWidget *parent, MainWindow *fat, graph *grafos) :
    QDialog(parent),
    ui(new Ui::Load)
{
    ui->setupUi(this);
    padre = fat;
    grafo = grafos;
}

Load::~Load()
{
    delete ui;
}
