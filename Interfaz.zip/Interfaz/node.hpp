#ifndef NODE_HPP
#define NODE_HPP

#include <string.h>
using namespace std;

class node {
private:
	string name;
	float cost;
	bool mark;
	node *nextV;
	node *nextA;

	void init (string name, float cost) {
		this->name = name;
		this->cost = cost;
		this->mark = false;
		this->nextV = nullptr;
		this->nextA = nullptr;
	}
public:
	node (string name) {
		init (name, 1);
	}

	node (string name, float cost) {
		init (name, cost);
	}

	string getName () { return name; }
	float getCost () { return cost; }
	node* getNextV () { return nextV; }
	node* getNextA () { return nextA; }
	bool getMark () { return mark; }

	void setCost  (float c) { cost = c; }
	void setNextV (node *v) { nextV = v; }
	void setNextA (node *a) { nextA = a; }
	void setMark () { mark = true; }
	void clearMark () { mark = false; }
};

#endif
