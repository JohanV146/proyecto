#include "analize.h"
#include "ui_analize.h"
#include "dialog.h"

Analize::Analize(QWidget *parent, MainWindow *fat, graph *grafos) :
    QDialog(parent),
    ui(new Ui::Analize)
{
    ui->setupUi(this);
    padre = fat;
    grafo = grafos;
}

Analize::~Analize()
{
    delete ui;
}

void Analize::on_btMatriz_clicked()
{
    Dialog *dg = new Dialog(this, this, grafo);
    dg->setModal(true);
    dg->show();
    this->close();

}


void Analize::on_btBusqueda_clicked()
{

}


void Analize::on_btTodosCaminos_clicked()
{

}


void Analize::on_btArbol_clicked()
{

}


void Analize::on_btRegresar_clicked()
{

}

